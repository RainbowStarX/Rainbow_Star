# HProxy-PHP
HProxy powered by PHP

# 使用教程
1.登录Github，先将这个 repo Fork到自己的帐号里（右上角）

2.打开[heroku](https://www.heroku.com/)， 点击[注册(Sign Up)](https://signup.heroku.com/)，注册一个帐号   

3.登陆之后默认就在[app面板](https://dashboard.heroku.com/apps)，点击右上角的News-Create new app    

4.然后输入名字，第二个选项是服务器所在位置，默认的美国不用改  

5.创建好之后，默认应该打开的是Deploy(部署) 选项卡，在Deployment method处选Github，登录并关联自己的Github帐号   

6.在Connect to GitHub这一栏，搜索HProxy，然后选中这个repo   

7.在最下面的Manual deploy这一栏，选中master，然后点Deploy Branch    

8.完成，接下来只要在应用的HProxy设置中填上这个app的地址（默认为https://<你填的名字>.herokuapp.com/）
